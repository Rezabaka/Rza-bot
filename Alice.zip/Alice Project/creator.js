const settings = require("./settings");
const funclist = require("./lib/funclist");
const functions = require("./system/functions");
const {
  BufferJSON,
  WA_DEFAULT_EPHEMERAL,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsSameUser,
  getContentType,
  downloadContentFromMessage,
} = global.baileys;
const fs = require("fs");
const util = require("util");
const FormData = require("form-data");
const cheerio = require("cheerio");
const filestack = require("filestack-js");
const client = filestack.init(settings.fileStackApi);
const chalk = require("chalk");
const crypto = require("crypto");
const { exec, spawn, execSync } = require("child_process");
const axios = require("axios");
const path = require("path");
const ms = require("parse-ms");
const jimp = require("jimp");
const { color, bgcolor, mycolor } = require("./lib/color");
const fetch = require("node-fetch");
const { sizeFormatter } = require("human-readable");

const winwin = fs.readFileSync("./creator.js");

module.exports = alice = async (conn, m, { msg, chatUpdate, store }) => {
  try {
    if (m.key && m.key.remoteJid === "status@broadcast") {
      return;
    }
    const body =
      m.mtype === "conversation"
        ? m.message.conversation
        : m.mtype == "imageMessage"
          ? m.message.imageMessage.caption
          : m.mtype == "videoMessage"
            ? m.message.videoMessage.caption
            : m.mtype == "extendedTextMessage"
              ? m.message.extendedTextMessage.text
              : ".";
    const budy = typeof m.text == "string" ? m.text : "";
    const prefix = /^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/.test(body)
      ? body.match(/^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/gi)
      : "";
    const isCmd = body.startsWith(prefix);
    const from = m.key.remoteJid;
    const args = body.trim().split(/ +/).slice(1);
    const isROwner = global.owner.includes(m.sender);
    const isOwner = global.owner.includes(m.sender);
    const command = isOwner
      ? body.replace(prefix, "").trim().split(/ +/).shift().toLowerCase()
      : m.text
        ? body.replace(prefix, "").trim().split(/ +/).shift().toLowerCase()
        : "";
    const usedPrefix = prefix + command;
    const text = args.join(" ");
    const q = args.join(" ");
    const quoted = m.quoted ? m.quoted : m;
    const qmsg = m.quoted || m;
    const sendText = (text) => conn.sendMessage(m.chat, { text });
    const isGroup = m.key.remoteJid.endsWith("@g.us");

    switch (command) {
      case "darwin":
      case "dalwin":
      case "developer":
      case "owner":
        if (!isGroup) {
          return true;
        }
        var response = generateWAMessageFromContent(
          m.chat,
          proto.Message.fromObject({
            contactMessage: {
              displayName: "© 𝙳𝙰𝚁𝚆𝙸𝙽",
              vcard:
                "BEGIN:VCARD\nVERSION:3.0\nN:;;;;\nFN: 𝙳𝙰 𝚆𝙷𝙰𝚃𝚂𝙰𝙿𝙿 ✆\nitem1.TEL;waid=6282318658612:+62823-1865-8612\nitem1.X-ABLabel:Ponsel\nPHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0Mv/bAEMBCQkJDAsMGA0NGDIhHCEyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAGAAYAMBIgACEQEDEQH/xAAcAAACAwEAAwAAAAAAAAAAAAAFBgMEBwIAAQj/xAAzEAACAQMDAwIDBwQDAQAAAAABAgMABBEFEiEGMUETUSJhgQcyUnGRocEUQrHwFXLRI//EABkBAAIDAQAAAAAAAAAAAAAAAAECAAMEBf/EACARAAICAgMBAQEBAAAAAAAAAAABAhEDIRIxQQRhIkL/2gAMAwEAAhEDEQA/AM9O1rrbGD6UR2rnzz3q6dQS0UYO5lwf0PmqD/8AxB+Hmg17ekMVVst7+1Y+DySOhzWONhO61h1ZfjJYFgu3uwbxUcVvfXKgliqBdo8nb7GqmlWxllWWQbjnPPk0+aVboFUsBxzVvGMdIr5ynt9C/b9MXM0W6QysSuOTj8qtv0dOyepGhUAB87ueDz+1O0dzEi4yB/7VpLxGRVBGACPp3qWShSt/s6up2b022gJkfEfPio7/AKB1awVngdmK+Ac8Af4rRrDUQqLk4JAz+lETepKOcGi6oitMw+HXtU0iYC5ZwA2SG5BP8U/6B1PDfKvZX/uXPb/c1Y6m6Ug1exkliRVl2nx3rHrS8udE1NkOQYnKlTVUsEZq49lkc8oOpbR9H2zhosg5BORU9LHRmrjUtOyTyo7E5xTMTW35pXiSfmjnfVGsrr3Z89dQuIr66VAFCysAPYbjSqd0svuzGm/ruxk03qC9gcEBpCyH8Sscg/v+1LumW7XF/GgHAO4/ICqoRpF2SVtIY9OgEcagDsAKPQTGNQBQZrlLVgm0s2OceK8XVdzbVib6mkpvZZGSQeM5ZQc8ipobk7lGeGIFBYLh3+J0IHtV9ASvHfuD86UsTsZoJPgGD+tFbVl2h3kVR5yaS5bmZol9NyoA5qpEbm4uVQSsxz+dMC2atbTQSExiRWzwOeKxn7R9I/4/qZpVXEVwoYY9+x/xWk6RBGsarLJlhzw3NUvtF0dbzpZr1fjktSG3eduef80YumJNNx2DvsoWVrW7chvTXCgnsT3rRmbarE+Bmkr7OrlRoEdrtUMi71ZRjcrHz8wQR+lN8rZjYZ5PFasUaiYssuUgD1v0xZ9Q6eHkf0rmEZSYDPw98MPIzWQ9NW/pX14kikPF8JBGCCCQf8Vv0qCVWR+3HasTS0lsupb15QQJpnRs/i4b98mlyrVobFK3TJGt4YNzuAckszNQufXLKOQoFZseVXii9/ZtdQlA7Kp7geaCXWgyXCRgbYyg27h2I/KqIpPs1Pl/kI2moRzIJI23KfBGCKNW59XAUZJ7AUHsNN2mNBlgiFM+DznJ9zmm/pywVrtEfxStK9Dq/QVqEE0MaqEOWOKSNTvr/wDqjDG8scRbaqxHlsHBzjuc+K3/AFPQ4ZYGQqM44OKSZtCu4bwtG+4E+VGRRi0nskouSq6KnT/SeqMbVoL/ANItGrusy7treQCOa0DW7JoujdRt52DH+kk3NjuQpP8AFQaDavaoGlbkdhV3qGb19Du4u++Mpj/tx/NRtOWg1URJ+z1DFpUbt97G0j25/wB/WnZ2zge7ClnQIBbRPGo2qrYA8dhTBuy6/U1rj0c6W2Xn4dgP7vNIl1pK3t9qceCHcrPC3sy5A/gfWtLubVDDJIq7WVS3yNIt7qVjp15A00qs7owKp8TZ74+XejKq2LjbbuIoE4xuUqfKkYIPtUsVss5GMmutVvIr6+kuYUaNXIJVjk58n61xaXBjbFYpaejpw2rLbwpawkgAY5q707cYvix+EYyM+RVG+nElq2CMmhJv7lLmIKFWJV2k5Ib6eKAapm1llvLYCNhuI7ml8XCi5ZJVCupwQaSbPV9Vu7qGO0vHiCsA2VByPn7CmHUZvSkWVpN0h+83bJqBpIZUnh28KBQHqvV4NN0xJpg5RplXCDJ7E9vpVaLUcqMN3pf6yuf6mK2td2fiMjD28D+akXuyTj/LCehdQ6Tcq6x30SyMxISRtrEceDTMjhmyDkbeDWLPpCSxrgbiRk5FSQNquj82Oo3ELfgRtyn6HitMcq9MTwvtG09a9QPFozQWMbCOYmMz+O3IHzrJLm5jEMRLZdQGAXv25rZtU02PWelZrGMbSY90ZXjDDkf786xWysXmlMWwqVJViR93B80mVNyQMHFRf4T2LT3bM5CxxL3Hck1cTvXqVBaosEZC7clSf7h7H5/xVUTurAhePIPmq5RpF0MtP8Lc7FYicE45oLcXjB9oRx8yOKLC4juAY8lZAM7W4OPce4/KuPSQHlQfzFL0XKSbs503VLtQEs7RWkbIckY/KrUp1QSK14Aqk/dHirulxW0cocuwc+BwKNGyl1K4jtoV3yOcAAcAe5+VRbHnKPaVAaK6EMe4ngUFuJHvbhp3bhuF/Ktgk6EsJdBOmhCtw2HN2y4Yt7Y8L4xWUXNhNbXsltOm14WKOvgEHFNKDj2UxyrJqPhEAANkY/M+K9D0o3+I7mPnFdSOqDaoGaqbyWOOT+KgFmwdM6tHcaRHOXAQLuJJ7ACka8eBtWunhj9OKdzKvPPz/wDfrXOmR3GnWElgs7Pbs2VyMNj8J+teXNtI4wgyyncPzrTJuqZhSVtorvAk4IIxk/pXEdksTfGufZsUQgtpDGH2HB/arMcRwQRz86Sh0wVNp1tfLtk+8v3WU4ZT8jUTaffWq59NbmP3HDAfzTAIlByRwfNTRpxyc4pXGx4za6ANhbpcTBPSeNvwk8/pWodL2SWNiriMJM7Esx+8R4BP8UB06Met6hxkcZprsQzDI4jA4Pzp8cKdiZsrlHiEpztIYnIPNZN9o9utv1CtwpCi4gWR/wDsCVP64Fafcy5QckkVl32k75NZssn4f6YY+XxNRy9C/O3yElmaRuMgVLHHkH2Hc11HCWPHC+9ShVJ2g4UcVmbN8Y+n/9k=\nX-WA-BIZ-DESCRIPTION:Developer & Creator Project Alice\nX-WA-BIZ-NAME:\nMy Name Is *Dalwin* 🙂\nEND:VCARD",
            },
          }),
          { userJid: m.sender, quoted: m },
        );
        conn.relayMessage(m.sender, response.message, {
          messageId: response.key.id,
        });
        conn.sendMessage(m.sender, {
          audio: fs.readFileSync("./assets/audio/Alice Team.m4a"),
          mimetype: "audio/mpeg",
          ptt: false,
        });
        break;

      case "sc":
      case "script":
      case "source":
        const uploadFile = { upload: conn.waUploadToServer };
        var imageMessage = await prepareWAMessageMedia(
          {
            image: { url: "https://telegra.ph/file/ebdb48d70f4d2c1944b69.jpg" },
          },
          uploadFile,
        );
        const product = {
          productImage: imageMessage.imageMessage,
          productId: "7066960336725723",
          title: "PROJECT ALICEZATION",
          description: "Nyari Apa Dek?",
          currencyCode: "IDR",
          priceAmount1000: "10000",
          productImageCount: 1,
        };
        const productData = {
          product: product,
          businessOwnerJid: "6285724700472@s.whatsapp.net",
        };
        const productMessage = { productMessage: productData };
        var response = await generateWAMessageFromContent(
          from,
          proto.Message.fromObject(productMessage),
          m.quoted && m.quoted.fromMe
            ? { contextInfo: { ...m.msg.contextInfo } }
            : { quoted: m },
        );
        await conn.relayMessage(from, response.message, {
          messageId: response.key.id,
        });
        await delay(3000);
        conn.sendMessage(from, {
          image: { url: "https://telegra.ph/file/abdc4e8fcd594f6dec303.jpg" },
          caption:
            "*ALICE PROJECT*\ncreator : 6285724700472\ndibuat : 21 mei, 2024\nlast update : Hari ini\nfeatures available : 1024+ command\nharga : Rp. 150,000\nfree fix service : *yes*\nfree update : *yes*\npreview bot : youtu.be/t-8bDvsLeM8?si=ja0fganGQ0oDd-lr",
        });
        await delay(2000);
        sendText(
          "berminat script di atas? kontak creator di\n\nwhatsapp : wa.me/6285724700472",
        );
        break;

      case "credit":
      case "creator":
      case "credits":
      case "infobot":
        let msg =
          "       *C R E A T O R    I N F O*\n───────────────────────────┈\n*Creator:* Rezaxd\n*Project Name:* Alice\n*Release Date:* 15, des, 2023\n*Versi Project:* v.1.2\n\n        *S O C I A L    M E D I A*\n───────────────────────────┈\n*YouTube:* youtube.com/@rezaxd_store\n*WhatsApp:* +62 857-2470-0472";
        const messageData = {
          video: { url: "https://telegra.ph/file/299df5713205340d27236.mp4" },
          mimetype: "video/mp4",
          fileLength: 10000000000,
          caption: msg,
          gifPlayback: true,
          gifAttribution: 5,
          contextInfo: {},
        };
        messageData.contextInfo.externalAdReply = {};
        messageData.contextInfo.externalAdReply.title = "PROVIDED BY ERLAN-TEAM";
        messageData.contextInfo.externalAdReply.body =
          "creator asli dari project script alice";
        messageData.contextInfo.externalAdReply.thumbnail = thumb;
        messageData.contextInfo.externalAdReply.sourceUrl =
          "https://wa.me/6285724700472";
        messageData.contextInfo.externalAdReply.mediaType = 1;
        messageData.contextInfo.externalAdReply.renderLargerThumbnail = false;
        conn.sendMessage(m.chat, messageData, { quoted: m });
        break;

      default:
        break;
    }
  } catch (error) {
    m.reply(util.format(error));
  }
};