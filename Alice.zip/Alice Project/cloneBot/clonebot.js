const { modul } = require("../module");
const {
  baileys,
  boom,
  chalk,
  fs,
  figlet,
  FileType,
  path,
  process,
  PhoneNumber,
} = modul;
const { Boom } = boom;
const Pino = require("pino");
const {
  default: makeWaSocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  makeInMemoryStore,
  jidDecode,
  proto,
  makeCacheableSignalKeyStore,
} = baileys;
const { color, bgcolor } = require("../lib/color");
const log = (pino = require("pino"));
const qrcode = require("qrcode");
const rimraf = require("rimraf");
const {
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid,
} = require("../lib/exif");
const {
  smsg,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetchJson,
  await,
  sleep,
  reSize,
} = require("../lib/myfunc");
const store = makeInMemoryStore({
  logger: pino().child({
    level: "silent",
    stream: "store",
  }),
});
if (global.conns instanceof Array) {
  console.log();
} else {
  global.conns = [];
}
const AliceClone = async (conn, m, _0x10ea16, _0x16d7ff) => {
  const { sendImage: sendImage, sendMessage: sendMessage } = conn;
  const { reply: reply, sender: sender } = m;
  const { state: state, saveCreds } = await useMultiFileAuthState(
    "./userclone/" + m.sender,
  );
  const { version: version, isLatest: isLatest } =
    await fetchLatestBaileysVersion();
  const store = makeInMemoryStore({
    logger: pino().child({
      level: "silent",
      stream: "store",
    }),
  });
  try {
    async function handler() {
      let { version: version, isLatest: isLatest } =
        await fetchLatestBaileysVersion();
      const p = {
        level: "fatal",
      };
      const conn = await makeWaSocket({
        auth: {
          creds: state.creds,
          keys: makeCacheableSignalKeyStore(
            state.keys,
            Pino(p).child({
              level: "fatal",
            }),
          ),
        },
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        mobile: false,
        printQRInTerminal: false,
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: true,
        getMessage: async (key) => {
          if (store) {
            const msg = await store.loadMessage(key.remoteJid, key.id);
            return msg?.message || undefined;
          }
          return {
            conversation: "Bot Here",
          };
        },
        logger: log({
          level: "silent",
        }),
        version: version,
      });
      if (!(await conn.authState.creds.registered)) {
        if (
          !Object.keys(await baileys.PHONENUMBER_MCC).some(
            (_0x233d46) => _0x16d7ff,
          )
        ) {
          const text = {
            text: "*REQUEST CONNECTION*\n\n             *How To Install*\n*1*. masuk ke *perangkat tertaut*\n*2*. klik *tautkan perangkat*\n*3*. klik masukan *dengan nomor telpon saja*\n*4*. masukan *code* anda\n\n*COPY YOUR CODE*",
          };
          const quoted = {
            quoted: m,
          };
          sendMessage(m.chat, text, quoted);
        }
        setTimeout(async () => {
            let code = await conn.requestPairingCode(parseInt(await m.sender.replace(/[^0-9]/g, "")));
            code = code?.match(/.{1,4}/g)?.join("-") || code;
            const message = {
              text: "" + code,
            };
            conn.sendMessage(m.from, message); // idk m.from, m.chat, m.sender
            console.log("Your code is: " + code);
          }, 3000);
        }
          
      conn.ws.on("CB:Blocklist", (_0x470da1) => {
        if (blocked.length > 2) {
          return;
        }
        for (let _0x148d49 of _0x470da1[1].blocklist) {
          blocked.push(_0x148d49.replace("c.us", "s.whatsapp.net"));
        }
      });
      conn.ws.on("CB:call", async (_0x4d1e3d) => {
        const _0x40e1cc = _0x4d1e3d.content[0].attrs["call-creator"];
        const _0x47c37c = _0x4d1e3d.content[0].attrs["call-id"];
        const _0x257cad = _0x4d1e3d.attrs.id;
        const _0x18ec63 = _0x4d1e3d.attrs.t;
        const _0x332e99 = {
          from: global.owner,
          id: _0x257cad,
          t: _0x18ec63,
        };
        const _0x447890 = {
          "call-creator": _0x40e1cc,
          "call-id": _0x47c37c,
          count: "0",
        };
        const _0x4c6b4b = {
          tag: "reject",
          attrs: _0x447890,
          content: null,
        };
        const _0x2c375f = {
          tag: "call",
          attrs: _0x332e99,
          content: [_0x4c6b4b],
        };
        conn.sendNode(_0x2c375f);
        if (_0x4d1e3d.content[0].tag == "offer") {
          let _0x263638 = await conn.sendContact(_0x40e1cc, global.owner);
          const _0x33c0ec = {
            quoted: _0x263638,
          };
          await conn.sendMessage(
            m.from,
            {
              text: "Block Automatic System!!!\nDon't Call Bot!!!\nPlease contact the owner to open the block!!!",
            },
            _0x33c0ec,
          );
          await sleep(8000);
          await conn.updateBlockStatus(_0x40e1cc, "block");
        }
      });
      conn.ev.on("messages.upsert", async (chatUpdate) => {
        try {
          kay = chatUpdate.messages[0];
          if (!kay.message) {
            return;
          }
          kay.message =
            Object.keys(kay.message)[0] === "ephemeralMessage"
              ? kay.message.ephemeralMessage.message
              : kay.message;
          if (kay.key && kay.key.remoteJid === "status@broadcast") {
            return;
          }
          if (!conn.public && !kay.key.fromMe && chatUpdate.type === "notify") {
            return;
          }
          if (kay.key.id.startsWith("BAE5") && kay.key.id.length === 16) {
            return;
          }
          m = smsg(conn, kay, store);
          require("../case")(conn, m, chatUpdate, store);
        } catch (error) {
          console.log(error);
        }
      });
      conn.public = true;
      store.bind(conn.ev);
      conn.ev.on("creds.update", saveCreds);
      conn.ev.on("connection.update", async (update) => {
        const { lastDisconnect: lastDisconnect, connection: connection } =
          update;
        if (connection == "connecting") {
          return;
        }
        if (connection) {
          if (connection != "connecting") {
            console.log("Connecting to bot..");
          }
        }
        console.log(_0x1f73ae);
        if (connection == "open") {
          conn.id = conn.decodeJid(conn.user.id);
          conn.time = Date.now();
          global.conns.push(conn);
          user = "" + conn.decodeJid(conn.user.id);
          txt = "@" + user.split("@")[0] + " mendaftar menjadi bot";
          const _0x4e2be6 = {
            text: txt,
            mentions: [user],
          };
          _0x946af3(global.owner, _0x4e2be6);
        }
        if (connection === "close") {
          let statusCode = new Boom(lastDisconnect?.error)?.output.statusCode;
          if (statusCode === DisconnectReason.badSession) {
            console.log(
              "Bad Session File, Please Delete Session and Scan Again",
            );
            conn.logout();
            sendText(m.sender, {
              text: '*[ System Notice ]" menghapus session',
            });
          } else if (statusCode === DisconnectReason.connectionClosed) {
            console.log("Connection closed, reconnecting....");
            handler();
          } else if (statusCode === DisconnectReason.connectionLost) {
            console.log("Connection Lost from Server, reconnecting...");
            handler();
          } else if (statusCode === DisconnectReason.connectionReplaced) {
            console.log(
              "Connection Replaced, Another New Session Opened, Please Close Current Session First",
            );
            conn.logout();
          } else if (statusCode === DisconnectReason.loggedOut) {
            console.log("Device Logged Out, Please Scan Again And Run.");
            conn.logout();
          } else if (statusCode === DisconnectReason.restartRequired) {
            console.log("Restart Required, Restarting...");
            handler();
            sendText(m.sender, {
              text: "*[ System Notice ]* merestart",
            });
          } else if (statusCode === DisconnectReason.timedOut) {
            console.log("Connection TimedOut, Reconnecting...");
            handler();
          } else {
            conn.end(
              "Unknown DisconnectReason: " + statusCode + "|" + connection,
            );
          }
        }
      });
      conn.decodeJid = (jid) => {
        if (!jid) {
          return jid;
        }
        if (/:\d+@/gi.test(jid)) {
          let decode = jidDecode(jid) || {};
          return (
            (decode.user &&
              decode.server &&
              decode.user + "@" + decode.server) ||
            jid
          );
        } else {
          return jid;
        }
      };
      conn.ev.on("contacts.update", (update) => {
        for (let contact of update) {
          let id = conn.decodeJid(contact.id);
          if (store && store.contacts) {
            store.contacts[id] = {
              id: id,
              name: contact.notify,
            };
          }
        }
      });
      conn.getName = (jid = "", withoutContact = false) => {
        jid = conn.decodeJid(jid);
        withoutContact = this.withoutContact || withoutContact;
        let v;
        if (jid.endsWith("@g.us"))
          return new Promise(async (resolve) => {
            v = conn.chats[jid] || {};
            if (!(v.name || v.subject))
              v = (await conn.groupMetadata(jid)) || {};
            resolve(
              v.name ||
                v.subject ||
                PhoneNumber("+" + jid.replace("@s.whatsapp.net", "")).getNumber(
                  "international",
                ),
            );
          });
        else
          v =
            jid === "0@s.whatsapp.net"
              ? {
                  jid,
                  vname: "WhatsApp",
                }
              : areJidsSameUser(jid, conn.user.id)
                ? conn.user
                : conn.chats[jid] || {};
        return (
          (withoutContact ? "" : v.name) ||
          v.subject ||
          v.vname ||
          v.notify ||
          v.verifiedName ||
          PhoneNumber("+" + jid.replace("@s.whatsapp.net", "")).getNumber(
            "international",
          )
        );
      };
      conn.parseMention = (text = "") => {
        return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(
          (v) => v[1] + "@s.whatsapp.net",
        );
      };
      conn.sendContact = async (jid, contact, quoted, info = {}, opts = {}) => {
        let list = [];
        contact.map((v) =>
          list.push({
            displayName: v.name,
            vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${v.name}\nORG:${info && info.org ? info.org : "Natsumi Support"}\nTEL;type=CELL;type=VOICE;waid=${v.number}:${PhoneNumber("+" + v.number).getNumber("international")}\nEMAIL;type=Email:${info && info.email ? info.email : "chat@natsumi.world"}\nURL;type=Website:${info && info.website ? info.website : "https://natsumi.world"}\nADR;type=Location:;;Unknown;;\nOther:${v.about}\nEND:VCARD`,
          }),
        );
        return conn.sendMessage(
          jid,
          {
            contacts: {
              displayName: `${list.length} Contact`,
              contacts: list,
            },
            ...opts,
          },
          { quoted },
        );
      };
      conn.sendImage = async (
        jid,
        path,
        caption = "",
        quoted = "",
        options,
      ) => {
        let buffer = Buffer.isBuffer(path)
          ? path
          : /^data:.*?\/.*?;base64,/i.test(path)
            ? Buffer.from(path.split`,`[1], "base64")
            : /^https?:\/\//.test(path)
              ? await await getBuffer(path)
              : fs.existsSync(path)
                ? fs.readFileSync(path)
                : Buffer.alloc(0);
        return await conn.sendMessage(
          jid,
          {
            image: buffer,
            caption: caption,
            ...options,
          },
          {
            quoted,
          },
        );
      };

      conn.copyNForward = async (
        jid,
        message,
        forceForward = false,
        options = {},
      ) => {
        let vtype;
        if (options.readViewOnce) {
          message.message =
            message.message &&
            message.message.ephemeralMessage &&
            message.message.ephemeralMessage.message
              ? message.message.ephemeralMessage.message
              : message.message || undefined;
          vtype = Object.keys(message.message.viewOnceMessage.message)[0];
          delete (message.message && message.message.ignore
            ? message.message.ignore
            : message.message || undefined);
          delete message.message.viewOnceMessage.message[vtype].viewOnce;
          message.message = {
            ...message.message.viewOnceMessage.message,
          };
        }

        let mtype = Object.keys(message.message)[0];
        let content = await generateForwardMessageContent(
          message,
          forceForward,
        );
        let ctype = Object.keys(content)[0];
        let context = {};
        if (mtype != "conversation")
          context = message.message[mtype].contextInfo;
        content[ctype].contextInfo = {
          ...context,
          ...content[ctype].contextInfo,
        };
        const waMessage = await generateWAMessageFromContent(
          jid,
          content,
          options
            ? {
                ...content[ctype],
                ...options,
                ...(options.contextInfo
                  ? {
                      contextInfo: {
                        ...content[ctype].contextInfo,
                        ...options.contextInfo,
                      },
                    }
                  : {}),
              }
            : {},
        );
        await conn.relayMessage(jid, waMessage.message, {
          messageId: waMessage.key.id,
        });
        return waMessage;
      };
      //   conn.sendButtonText = (_0x3252e9, _0x54340f = [], _0x2b8db7, _0x1b6b73, _0x23e7e4 = "", _0x1a3fd7 = {}) => {
      //     const _0x3a03a0 = {
      //       text: _0x2b8db7,
      //       footer: _0x1b6b73,
      //       buttons: _0x54340f,
      //       headerType: 2,
      //       ..._0x1a3fd7
      //     };
      //     let _0x5d9910 = _0x3a03a0;
      //     const _0x2f63ef = {
      //       quoted: _0x23e7e4,
      //       ..._0x1a3fd7
      //     };
      //     conn.sendMessage(_0x3252e9, _0x5d9910, _0x2f63ef);
      //   };
      conn.ments = (text = "") => {
        if (text.match("@")) {
          return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(
            (_0x266401) => _0x266401[1] + "@s.whatsapp.net",
          );
        } else {
          return [];
        }
      };
      conn.sendteks = async (
        jid,
        text = "",
        quotedMessage = "",
        options = {},
      ) => {
        const quoted = {
          quoted: quotedMessage,
        };
        return conn.sendMessage(
          _0x170adb,
          {
            text: text,
            mentions: await conn.ments(text),
            ...options,
          },
          quoted,
        );
      };
      conn.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path)
          ? path
          : /^data:.*?\/.*?;base64,/i.test(path)
            ? Buffer.from(path.split`,`[1], "base64")
            : /^https?:\/\//.test(path)
              ? await await getBuffer(path)
              : fs.existsSync(path)
                ? fs.readFileSync(path)
                : Buffer.alloc(0);
        let buffer;
        if (options && (options.packname || options.author)) {
          buffer = await writeExifImg(buff, options);
        } else {
          buffer = await imageToWebp(buff);
        }

        await conn.sendMessage(
          jid,
          {
            sticker: {
              url: buffer,
            },
            ...options,
          },
          {
            quoted,
          },
        );
        return buffer;
      };
      conn.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path)
          ? path
          : /^data:.*?\/.*?;base64,/i.test(path)
            ? Buffer.from(path.split`,`[1], "base64")
            : /^https?:\/\//.test(path)
              ? await await getBuffer(path)
              : fs.existsSync(path)
                ? fs.readFileSync(path)
                : Buffer.alloc(0);
        let buffer;
        if (options && (options.packname || options.author)) {
          buffer = await writeExifVid(buff, options);
        } else {
          buffer = await videoToWebp(buff);
        }

        await conn.sendMessage(
          jid,
          {
            sticker: {
              url: buffer,
            },
            ...options,
          },
          {
            quoted,
          },
        );
        return buffer;
      };
      conn.sendCatalog = async (
        jid,
        title = "",
        description = "",
        imageUrl,
        options = {},
      ) => {
        const mediaObject = {
          image: imageUrl,
        };
        const uploader = {
          upload: conn.waUploadToServer,
        };
        let mediaMessage = await prepareWAMessageMedia(mediaObject, uploader);
        const productMessageContent = generateWAMessageFromContent(
          chatId,
          {
            productMessage: {
              product: {
                productImage: mediaMessage.imageMessage,
                productId: "9999",
                title: title,
                description: description,
                currencyCode: "INR",
                priceAmount1000: "100000",
                url: "https://youtube.com/channel/UC7NslQroUqQYzo2wDFBOUMg",
                productImageCount: 1,
                salePriceAmount1000: "0",
              },
              businessOwnerJid: "6283877118785@s.whatsapp.net",
            },
          },
          options,
        );
        return conn.relayMessage(jid, productMessageContent.message, {
          messageId: productMessageContent.key.id,
        });
      };

      /* Ga guna bjir udah ga work jugaan */
      //   conn.send5ButLoc = async (_0x5be5fb, _0x54f1bb = "", _0xee541d = "", _0x57c6c9, _0x32fe60 = [], _0x3205a2 = {}) => {
      //     const _0x546878 = {
      //       jpegThumbnail: _0x57c6c9
      //     };
      //     const _0x4939ab = {
      //       hydratedContentText: _0x54f1bb,
      //       locationMessage: _0x546878,
      //       hydratedFooterText: _0xee541d,
      //       hydratedButtons: _0x32fe60
      //     };
      //     const _0x408f24 = {
      //       hydratedTemplate: _0x4939ab
      //     };
      //     const _0x49049b = {
      //       templateMessage: _0x408f24
      //     };
      //     var _0x1c666c = generateWAMessageFromContent(_0x5be5fb, proto.Message.fromObject(_0x49049b), _0x3205a2);
      //     conn.relayMessage(_0x5be5fb, _0x1c666c.message, {
      //       messageId: _0x1c666c.key.id
      //     });
      //   };
      //   conn.sendButImg = async (_0x281465, _0x2a443a, _0x1d371d, _0x2dcd17, _0x4943c3) => {
      //     let _0x269711 = Buffer.isBuffer(_0x2a443a) ? _0x2a443a : /^data:.*?\/.*?;base64,/i.test(_0x2a443a) ? Buffer.from(_0x2a443a.split`,`[1], "base64") : /^https?:\/\//.test(_0x2a443a) ? await await getBuffer(_0x2a443a) : fs.existsSync(_0x2a443a) ? fs.readFileSync(_0x2a443a) : Buffer.alloc(0);
      //     const _0x4f4ab2 = {
      //       image: _0x269711,
      //       jpegThumbnail: _0x269711,
      //       caption: _0x1d371d,
      //       fileLength: "1",
      //       footer: _0x2dcd17,
      //       buttons: _0x4943c3,
      //       headerType: 4
      //     };
      //     let _0x1ff287 = _0x4f4ab2;
      //     const _0x4c8030 = {
      //       quoted: m
      //     };
      //     conn.sendMessage(_0x281465, _0x1ff287, _0x4c8030);
      //   };
      conn.setStatus = (status) => {
        conn.query({
          tag: "iq",
          attrs: {
            to: "@s.whatsapp.net",
            type: "set",
            xmlns: "status",
          },
          content: [
            {
              tag: "status",
              attrs: {},
              content: Buffer.from(status, "utf-8"),
            },
          ],
        });
        return buffer;
      };
      conn.imgToSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path)
          ? path
          : /^data:.*?\/.*?;base64,/i.test(path)
            ? Buffer.from(path.split`,`[1], "base64")
            : /^https?:\/\//.test(path)
              ? await await getBuffer(path)
              : fs.existsSync(path)
                ? fs.readFileSync(path)
                : Buffer.alloc(0);
        let buffer;
        if (options && (options.packname || options.author)) {
          buffer = await writeExifImg(buff, options);
        } else {
          buffer = await imageToWebp(buff);
        }

        await conn.sendMessage(
          jid,
          {
            sticker: {
              url: buffer,
            },
            ...options,
          },
          {
            quoted,
          },
        );
        return buffer;
      };
      conn.vidToSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path)
          ? path
          : /^data:.*?\/.*?;base64,/i.test(path)
            ? Buffer.from(path.split`,`[1], "base64")
            : /^https?:\/\//.test(path)
              ? await await getBuffer(path)
              : fs.existsSync(path)
                ? fs.readFileSync(path)
                : Buffer.alloc(0);
        let buffer;
        if (options && (options.packname || options.author)) {
          buffer = await writeExifVid(buff, options);
        } else {
          buffer = await videoToWebp(buff);
        }
        await conn.sendMessage(
          jid,
          {
            sticker: {
              url: buffer,
            },
            ...options,
          },
          {
            quoted,
          },
        );
        return buffer;
      };
      conn.downloadAndSaveMediaMessage = async (
        message,
        filename,
        attachExtension = true,
      ) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || "";
        let messageType = message.mtype
          ? message.mtype.replace(/Message/gi, "")
          : mime.split("/")[0];
        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk]);
        }
        let type = await FileType.fromBuffer(buffer);
        trueFileName = attachExtension ? filename + "." + type.ext : filename;
        // save to file
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
      };
      conn.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || "";
        let messageType = message.mtype
          ? message.mtype.replace(/Message/gi, "")
          : mime.split("/")[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk]);
        }
        return buffer;
      };
      conn.sendText = (jid, text, quoted = "", options) =>
        conn.sendMessage(
          jid,
          {
            text: text,
            ...options,
          },
          {
            quoted: quoted,
          },
        );
    }
    await handler();
  } catch (error) {
    console.log(error);
  }
};
async function stopjadibot(conn, jid, m) {
  if (!Object.keys(conn).includes(jid)) {
    return conn.sendteks(m.chat, "Kamu tidak ada di list jadi bot.", m);
  }
  try {
    conn[jid].end("stop");
  } catch {}
  try {
    conn[jid].logout();
  } catch {}
  delete conn[jid];
  delete db.jadibot[jid];
  rimraf.sync("./userclone/" + jid.split("@")[0]);
  return conn.sendteks(m.chat, "Sukses stop jadi bot.", m);
}
const nguwawor = {
  AliceClone: AliceClone,
  stopjadibot: stopjadibot,
};
module.exports = nguwawor;
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update " + __filename));
  delete require.cache[file];
  require(file);
});